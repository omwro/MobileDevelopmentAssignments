package nl.omererdem.madlevel2example

data class Reminder (
    var reminderText: String
)