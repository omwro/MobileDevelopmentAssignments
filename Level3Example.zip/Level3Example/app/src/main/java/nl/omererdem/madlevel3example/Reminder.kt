package nl.omererdem.madlevel3example

data class Reminder (
    var reminderText: String
)